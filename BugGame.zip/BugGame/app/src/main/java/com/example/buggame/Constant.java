package com.example.buggame;

import android.content.Context;

public class Constant {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;

    public static Context CURRENT_CONTEXT;
}
