package com.example.buggame;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;


public class Player implements GameObject {

    private Rect rectangle;
    private int color;




    public Rect getRectangle(){
        return rectangle;
    }

    public Player(Rect rectangle, int color){
        this.rectangle = rectangle;
        this.color = color;
    }





    @Override
    public void draw(Canvas canvas){

        BitmapFactory bf = new BitmapFactory();
        Bitmap idleImg = bf.decodeResource(Constant.CURRENT_CONTEXT.getResources(), R.drawable.ladybug1);

    Paint paint = new Paint();
    paint.setColor(color);

    canvas.drawBitmap(idleImg, null, rectangle, null);
    //canvas.drawRect(rectangle, paint);



    }


    @Override
    public void update(){

    }


    public void update(Point point){



        rectangle.set(point.x - rectangle.width()/2, point.y - rectangle.height()/2, point.x + rectangle.width()/2, point.y + rectangle.height()/2);



    }
}
