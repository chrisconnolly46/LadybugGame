package com.example.buggame;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;

public class Spider implements GameObject {

    private Rect rectangle;
    private Rect rectangle2;
    private Rect rectangle3;

    private int color;


    public Rect getRectangle(){
        return rectangle;
    }

    public void incrementY(float y) {
        rectangle.top += y;
        rectangle.bottom += y;
        rectangle2.top += y;
        rectangle2.bottom += y;
        rectangle3.top += y;
        rectangle3.bottom += y;

    }

    public Spider(int rectHeight, int color, int startX, int startY, int playerGap){

        this.color = color;


        int thirdR = (int)((Math.random() * 100) + 75);

        //left rectangle
        rectangle = new Rect(0, startY, startX, startY + rectHeight);

        //middle rect
        rectangle2 = new Rect((startX + playerGap), startY+300, (startX + playerGap +thirdR), startY + rectHeight+300);

        //right rect
        rectangle3 = new Rect(startX + playerGap + thirdR + playerGap, startY + 200, Constant.SCREEN_WIDTH, startY + rectHeight + 200);

    }


    public boolean collision(Player player){
        return (Rect.intersects(rectangle, player.getRectangle()) || Rect.intersects(rectangle2, player.getRectangle()) || Rect.intersects(rectangle3, player.getRectangle()));

    }


    @Override
    public void draw(Canvas canvas) {

        BitmapFactory bf = new BitmapFactory();
        Bitmap spiderImg = bf.decodeResource(Constant.CURRENT_CONTEXT.getResources(), R.drawable.spider);


        canvas.drawBitmap(spiderImg, null, rectangle, null);
        canvas.drawBitmap(spiderImg, null, rectangle2, null);
        canvas.drawBitmap(spiderImg, null, rectangle3, null);

        Paint paint = new Paint();
        paint.setColor(color);
       //canvas.drawRect(rectangle, paint);
        //canvas.drawRect(rectangle2, paint);
        //canvas.drawRect(rectangle3, paint);

    }

    @Override
    public void update() {

    }
}
