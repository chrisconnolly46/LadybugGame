package com.example.buggame;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.ArrayList;

public class SpiderManager {
    private ArrayList<Spider> enemy;
    private int playerGap;
    private int enemyGap;
    private int spiderHeight;
    private int color;

    private long startTime;
    private long initTime;

    private int score = 0;

    public SpiderManager(int playerGap, int enemyGap, int spiderHeight, int color) {
        this.playerGap = playerGap;
        this.enemyGap = enemyGap;
        this.spiderHeight = spiderHeight;
        this.color = color;

        startTime = initTime = System.currentTimeMillis();
        enemy = new ArrayList<>();

        makeSpiders();
    }

    public boolean collision(Player player) {
        for(Spider sp : enemy) {
            if(sp.collision(player))
                return true;
        }
        return false;
    }

    private void makeSpiders() {
        //
        int currentY = -5 * Constant.SCREEN_HEIGHT/4;
        while(currentY < 0) {
            int xStart = (int)(Math.random()*(Constant.SCREEN_WIDTH - playerGap));

            enemy.add(new Spider(spiderHeight, color, xStart, currentY, playerGap));
            currentY += spiderHeight + enemyGap;
        }
    }

    public void update() {
        //for speed control of enemies
        int elapsedTime = (int) (System.currentTimeMillis() - startTime);
        startTime = System.currentTimeMillis();
        float speed = (float)(Math.sqrt(1 + (startTime - initTime)/2000.0)) * Constant.SCREEN_HEIGHT/(10000.0f);
        for(Spider sp : enemy) {
            sp.incrementY(speed * elapsedTime);

        }
        //takes out enemies and increments the score once they hit the bottom
        if(enemy.get(enemy.size() - 1).getRectangle().top >= Constant.SCREEN_HEIGHT) {
            int xStart = (int)(Math.random()*(Constant.SCREEN_WIDTH - playerGap));
            enemy.add(0, new Spider(spiderHeight, color, xStart, enemy.get(0).getRectangle().top - spiderHeight - enemyGap, playerGap));
            enemy.remove(enemy.size() - 1);
            score++;
        }
    }

    //score incrementer
    public void draw(Canvas canvas){
        for(Spider sp : enemy)
            sp.draw(canvas);
        Paint paint = new Paint();
        paint.setTextSize(100);
        paint.setColor(Color.BLUE);
        canvas.drawText("" + score, 925, 50 + paint.descent() - paint.ascent(), paint);
    }
}
